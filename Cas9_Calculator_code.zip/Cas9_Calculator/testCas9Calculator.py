from Cas9_Calculator import *

if __name__ == "__main__":

    guideSequence = 'TACGTACACAAGAGCTCTAG'   
    Cas9Calculator=clCas9Calculator(['/var/www/salislab/software/DNAc/GenomeCalculations/NC_000913.gbk'])
    sgRNA1 = sgRNA(guideSequence, Cas9Calculator)
    sgRNA1.run()
    sgRNA1.exportAsDill()
    sgRNA1.printTopTargets()

